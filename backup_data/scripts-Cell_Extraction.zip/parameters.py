paths = './input'
output = './output'
merging_threshold = 9
N_seg = 9
TC = 190
dopant_region_check = 10
